"""物联网云平台 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path

from app01 import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('guanlizhuye/', views.guanlizhuye),
    # path('charlist/', views.char_list),
    path('tubiao/', views.tubiao),
    path('tubiao_add/', views.tubiao_add),
    # 新入住住户
    path('renshuguanli/', views.renshuguanli),
    path('xinzhuhu/', views.xinzhuhu),
    path('zhuhu/<int:nid>edit/', views.zhuhu_edit),
    path('zhuhu/<int:nid>delete/', views.zhuhu_delete),
# 车牌
    path('chepai/list/', views.chepai_list),
    path('chepai/add/', views.chepai_add),
    path('chepai/<int:nid>edit/', views.chepai_edit),
    path('chepai/<int:nid>delete/', views.chepai_delete),
# 管理员登录
    path('denglu/', views.denglu),

# 用户主页
    path('yonghu/', views.yonghu),
    path('chenggong/', views.chenggong),
# 用户登录
    path('yonghudenglu/', views.yonghudenglu),
    path('yonghuzhuce/', views.yonghuzhuce),
    path('zhucechenggong/', views.zhucechenggong),

    path('denglu_list/', views.yonghudenglu_list),
    path('denglu/<int:nid>delete/', views.denglu_delete),
    path('denglu/<int:nid>edit/', views.denglu_edit),


# 门禁下发
#     path('xiafa/', views.xiafa),
# 设备
    path('shebei/', views.shebei),
    path('shebei/add/', views.shebei_add),
    path('shebei/<int:nid>delete/', views.shebei_delete),
    path('shebei/<int:mid>use/', views.shebei_use),
    path('shebei/<int:mid>close/', views.shebei_close),
# 核酸检测
    path('jiance/', views.jiance),
    path('jiance/add/', views.jiance_add),
]
