from django.shortcuts import render, redirect,HttpResponse

# Create your views here.
# 管理主页
# from paho import mqtt
# import paho.mqtt.client as mqtt
from app01 import models
from app01.models import Denglu


def guanlizhuye(request):
    objs = models.People.objects.all()
    queryset = models.Xinzhuhu.objects.all()
    # return render(request,'guanlizhuye.html',{'objs':objs})
    return render(request,'guanlizhuye.html',{'objs':objs,
                                              'queryset':queryset,
                                              })

# 实时图
# import random
# import time
# from django.http import JsonResponse, request
# from django.shortcuts import render
# from django.views.decorators.csrf import csrf_exempt
# @csrf_exempt
# def char_list(request):
#     if request.method == 'POST':
#         now_time = time.strftime("%H:%M:%S")
#         num = random.randint(0,5)
#         return JsonResponse({"datas": {"local_time": now_time, "num": num}})
#     return render(request, 'char_list.html')
def tubiao(request):
    objs = models.People.objects.all()
    return render(request,'tubiao.html',locals())
def tubiao_add(request):
    if request.method == 'GET':
        return render(request, 'tubiao_add.html')

    # 获取提交的数据
    leixing = request.POST.get('leixing')
    renshu = request.POST.get('renshu')

    # 保存到数据库
    models.People.objects.create(leixing=leixing,renshu=renshu)

    # 重定向回部门列表
    return redirect('/tubiao/')
# 增加住户
from django import forms
class XinModelForm(forms.ModelForm):
    class Meta:
        model = models.Xinzhuhu
        fields = ['card','name','menpaihao','legal','zhuhuleiixng']

# 保存样式
def __init__(self,*args,**kwargs):
    super().__init__(*args,**kwargs)
# 添加样式
    for name,field in self.items():
        field.widget.attrs = {'class':'form-control','placeholder':field.label}
# 增加
def xinzhuhu(request):
    if request.method == 'GET':
       form = XinModelForm()
       return render(request,'xinzhuhu.html',{'form':form})

# 提交
    form = XinModelForm(data=request.POST)
    if form.is_valid():
        form.save()
        return redirect('/chenggong/')
def chenggong(request):
    return render(request,'chenggong.html')
# 小区总住户管理
def renshuguanli(request):
    queryset = models.Xinzhuhu.objects.all()
    return render(request,'zhuhuguanli.html',{'queryset':queryset})
def zhuhu_delete(request,nid):
    models.Xinzhuhu.objects.filter(id=nid).delete()
    return redirect('/renshuguanli/')
def zhuhu_edit(request,nid):
    if request.method == 'GET':
      row_object = models.Xinzhuhu.objects.filter(id = nid).first()
      form = XinModelForm(instance=row_object)
      return render(request,'zhuhu_edit.html',{'form':form})

    row_object = models.Xinzhuhu.objects.filter(id = nid).first()
    form = XinModelForm(data=request.POST,instance=row_object)
    if form.is_valid():
        form.save()
        return redirect('/renshuguanli/')
    return render(request,'zhuhu_edit.html',{'form':form})
# 车牌管理
def chepai_list(request):
    queryset1 = models.Car.objects.all()
    return render(request,'chepai_list.html',{'queryset1':queryset1})

class CarModelForm(forms.ModelForm):
    class Meta:
        model = models.Car
        fields = ['name','chepaihao','call',]


# 增加
def chepai_add(request):
    if request.method == 'GET':
       form = CarModelForm()
       return render(request,'chepai_add.html',{'form':form})
#
    form = CarModelForm(data=request.POST)
    if form.is_valid():
        form.save()
        return redirect('/chenggong/')
# 车牌信息修改
def chepai_edit(request,nid):
    if request.method == 'GET':
      row_object = models.Car.objects.filter(id = nid).first()
      form = CarModelForm(instance=row_object)
      return render(request,'chepai_edit.html',{'form':form})

    row_object = models.Car.objects.filter(id = nid).first()
    form = CarModelForm(data=request.POST,instance=row_object)
    if form.is_valid():
        form.save()
        return redirect('/chepai/list/')
    return render(request,'chepai_edit.html',{'form':form})
# 车牌删除
def chepai_delete(request,nid):
    models.Car.objects.filter(id=nid).delete()
    return redirect('/chepai/list/')

# 管理员登录
def denglu(request):
# 如果是get请求
    if request.method == 'GET':
        return render(request,'denglu.html')

# 如果是POST请求，则获取用户提交的数据
    else:
        username = request.POST.get('user')
        password = request.POST.get('pwd')
# 对用户提交的数据进行比对,正确的话跳转主页
        if username == '王梓默' and password == 'woailulu5201314':
            return render(request,'guanlizhuye.html')
#错误的话提示错误
        else:
            return render(request,'denglu.html',{"error_msg":"用户名或密码错误"})

# zhuyemian
def yonghu(request):
    return render(request,'index.html')
# 用户登录
def yonghudenglu(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        password = request.POST.get('password')

        if Denglu.objects.filter(name=name):
            Denglu.objects.filter(name=name)
            if Denglu.objects.filter(name = name)[0].password == password:
                return render(request,'index.html')
            else:
                return HttpResponse('密码错误，登录失败')
    return render(request,'yonghudenglu.html')
# 用户注册
def yonghuzhuce(request):
    if request.method == 'GET':
        return render(request, 'yonghuzhuce.html')

    name = request.POST.get('name')
    password = request.POST.get('password')
    models.Denglu.objects.create(name=name, password=password)
    return redirect('/zhucechenggong/')
# 注册成功页面
def zhucechenggong(request):
    return render(request,'zhucechenggong.html')

# 管理用户信息的增删改
def yonghudenglu_list(request):
    queryset3 = models.Denglu.objects.all()
    return render(request,'guanliyonghudenglu.html',{'queryset3':queryset3})
def denglu_delete(request,nid):
    models.Denglu.objects.filter(id = nid).delete()
    return redirect('/denglu_list/')
def denglu_edit(request,nid):
    # 根据id获取他的原数据
    if request.method == 'GET':
        row_object = models.Denglu.objects.filter(id=nid).first()
        print()
        return render(request, 'denglu_edit.html', {'row_object': row_object})
# 提交修改值
    name = request.POST.get('name')
    password = request.POST.get('password')
    models.Denglu.objects.filter(id=nid).update(name=name,password=password)
    return redirect('/denglu_list/')
# 设备列表
def shebei(request):
    # shebei = models.Shebei.objects.all()
    # return render(request,'shebei_list.html',{'shebei':shebei})
    # 搜索
    data_dict = {}
    search_data = request.GET.get('q','')
    if search_data:
        data_dict["name__contains"] = search_data
    shebei = models.Shebei.objects.filter(**data_dict).order_by("name")
    return render(request,'shebei_list.html',{'shebei':shebei,'search_data':search_data})
# 设备增加：
def shebei_add(request):
    if request.method == 'GET':
        return render(request, 'shebei_add.html')
        # 获取提交的数据
    name = request.POST.get('name')
    # 保存到数据库
    models.Shebei.objects.create(name = name, state='离线')
    # 重定向回部门列表
    return redirect('/shebei/')
# 设备删除
def shebei_delete(request,nid):
    models.Shebei.objects.filter(id = nid).delete()
    return redirect('/shebei/')
# 使用设备
def shebei_use(request,mid):
    models.Shebei.objects.filter(id = mid).update(state = '在线')
    return redirect('/shebei/')
# 关闭设备
def shebei_close(request,mid):
    models.Shebei.objects.filter(id = mid).update(state = '离线')
    return redirect('/shebei/')
# 下发命令
# def xiafa(request):
#     if request.method == 'GET':
#         return render(request, 'xiafa.html')
# # mqtt
#     mingling = request.POST.get('mingling')
#     print(mingling)
#     data = str(mingling)
#     client = mqtt.Client()
#     client.connect('localhost',1883)
#     client.publish('ceshi',data,1)
#     return render(request,'xiafa.html')
# 检测
def jiance(request):
    result = models.Jiance.objects.all()
    return render(request,'jianche.html',{'result':result})
class JianModelForm(forms.ModelForm):
    class Meta:
        model = models.Jiance
        fields = ['name','age','result']
# 增加
def jiance_add(request):
    if request.method == 'GET':
       form = JianModelForm()
       return render(request,'jiance_add.html',{'form':form})
#
    form = JianModelForm(data=request.POST)
    if form.is_valid():
        form.save()
        return redirect('/jiance/')