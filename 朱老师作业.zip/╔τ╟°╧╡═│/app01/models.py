from django.db import models


class People(models.Model):
    leixing = models.CharField(verbose_name='类型',max_length=32)
    renshu = models.CharField(verbose_name='人数', max_length=64)
    # 转换为汉字
    def __str__(self):
        return self.leixing
class Xinzhuhu(models.Model):
    card = models.CharField(verbose_name='门禁卡号', max_length=64)
    name = models.CharField(verbose_name='姓名',max_length=32)
    menpaihao = models.CharField(verbose_name='门牌号', max_length=64)
    legal = models.CharField(verbose_name='是否合法', max_length=64)
    zhuhuleiixng = models.ForeignKey(verbose_name='新住户类型选择', to='People', to_field='id', on_delete=models.CASCADE)
  # 转换为汉字
    def __str__(self):
        return self.name
# 车牌号表
class Car(models.Model):
    name = models.ForeignKey(verbose_name='用户姓名', to='Xinzhuhu', to_field='id', on_delete=models.CASCADE)
    chepaihao = models.CharField(verbose_name='车牌号', max_length=64)
    call = models.CharField(verbose_name='联系方式', max_length=32)
# 用户登录表
class Denglu(models.Model):
    name = models.CharField(verbose_name='用户姓名', max_length=32)
    password = models.CharField(verbose_name='用户密码', max_length=32)

# 设备表
class Shebei(models.Model):
    name = models.CharField(verbose_name='设备名称', max_length=32)
    state = models.CharField(verbose_name='设备状态', max_length=32)
# 核酸检测
class Jiance(models.Model):
    name = models.ForeignKey(verbose_name='用户姓名', to='Xinzhuhu', to_field='id', on_delete=models.CASCADE)
    age = models.CharField(verbose_name='年龄', max_length=32)
    result = models.CharField(verbose_name='核酸结果', max_length=32)